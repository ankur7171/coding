<?php
ini_set('display_errors', 1);
// using SendGrid's PHP Library
// https://github.com/sendgrid/sendgrid-php
require 'vendor/autoload.php'; // If you're using Composer (recommended)
// Comment out the above line if not using Composer
// require("./sendgrid-php.php");
// If not using Composer, uncomment the above line
$email = new \SendGrid\Mail\Mail();
$email->setFrom("karthik.yarabati@gmail.com", "Example User");
$email->setSubject("Sending with SendGrid is Fun");
$email->addTo("karthik.yarabati@gmail.com", "Example User");
$email->addContent(
    "text/plain", "and easy to do anywhere, even with PHP"
);
$email->addContent(
    "text/html", "<strong>and easy to do anywhere, even with PHP</strong>"
);
$sendgrid = new \SendGrid('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');
//$sendgrid = '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';
try {
    $response = $sendgrid->send($email);
    print $response->statusCode() . "\n";
    print_r($response->headers());
    print $response->body() . "\n";
} catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";
}
?>