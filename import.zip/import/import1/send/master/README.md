CSVtoMySQL Readme

While working on a web development project at Space-O Technologies, one of my responsibilities included to import old website data into new database. But luckily, I had a simple solution for this by creating a CSV to store old website data and then importing CSV into MySQL database for the new site.

I have created a demo on it and written a tutorial [How to Import CSV Into MySQL Database With PHP](https://www.spaceotechnologies.com/import-csv-mysql-database/).

If you face any issue implementing it, you can contact me for help. Also, if you want to implement this feature in your iOS app and looking to [hire PHP developer](
http://www.spaceotechnologies.com/hire-php-developer/ ) to help you, then you can contact Space-O Technologies for the same.


