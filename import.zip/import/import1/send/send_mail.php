<?php
//send_mail.php
header('Content-Type: text/html; charset=UTF-8');
require("sendgrid/sendgrid-php.php");
//ini_set("display_errors",1);
//include_once  ('index.php');
$conn = mysqli_connect('localhost:3308','root','admin','email');
	//get mail template
	$sql = "SELECT template FROM mail_template where id ='1'";
	$result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        // output data of each row
        while($row = mysqli_fetch_assoc($result)) {
            $template = $row["template"];
        }
    }
if(isset($_POST["name"]))
{
$name = $_POST["name"];
$email1 = $_POST["email"];
// Here, you can also perform some database query operations with above values.
echo "Welcome ". $name ."!"; // Success Message
}

/*if(isset($_POST['fname1']))  (trim($_POST['fname1'])!= "") ;
		$email1 	= $_POST['fname1'];
	echo $email1;*/
if(isset($_POST['email_data']))
{
	require 'class/class.phpmailer.php';
	$output = '';
	foreach($_POST['email_data'] as $row)
	{
		$name = $row["name"];
		$html = '<!DOCTYPE html><html><b>Dear Dr.  '.$name.',</b></br><br>';
            $html .= $template;
            $html .= '</html>';
		$email = new \SendGrid\Mail\Mail(); 
$email->setFrom("lukeharris@innovinc.org", "lukehar ris");
$email->setSubject($row["fname"]);
$email->addTo($row["email"], $row["name"]);
//sleep(20);
$email->addContent("text/plain", "and easy to do anywhere, even with PHP");
$email->addContent(
   "text/html", $html
);
$sendgrid = new \SendGrid('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');
try {
    $response = $sendgrid->send($email);
   // print $response->statusCode() . "\n";
    //print_r($response->headers());
   // print $response->body() . "\n";
}
 catch (Exception $e) {
    echo 'Unable to send mail: '. $e->getMessage() ."\n";
}
	}						//Send an Email. Return true on success or false on error
    if ($response->statusCode() == 202) {
     // Successfully sent
     echo 'done';
    } else {
     echo 'false';
    }
}
?>